# Create Yanvex App

Create modern React applications with Vite, Tailwind CSS v4, Authentication, Protected Routes, Public Routes, and optional shadcn/ui support.

## Quick Start

```bash
npx create-init-app@latest my-app
```

or

```bash
npm create yanvex-app@latest my-app
```

---

## Features

* React + Vite
* JavaScript or TypeScript
* Tailwind CSS v4
* Public Routes
* Protected Routes
* Authentication Context
* Home Page
* Login Page
* Dashboard Page
* Optional shadcn/ui setup
* Interactive CLI using arrow-key navigation

---

## Usage

```bash
npx create-init-app@latest
```

The CLI will guide you through:

* Project Name
* Framework Selection
* JavaScript / TypeScript
* shadcn/ui Setup
* Additional Features

---

## Development

Clone repository:

```bash
git clone <repository-url>
cd create-init-app
npm install
```

Test locally:

```bash
npm link
create-init-app
```

Remove local link:

```bash
npm unlink -g create-init-app
```

---

## Publishing

```bash
npm version patch
npm publish
```

---

## Requirements

* Node.js 20+
* npm 9+

---

## License

MIT
